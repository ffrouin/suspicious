# Suspicious

IT Threats GeoDashboard

# Backend lib

This is the place where we will find share perl lib that will be used by
suspicious.pl and as well by processors scripts.
