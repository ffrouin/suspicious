# Suspicious

IT Threats GeoDashboard

# Backend logs

This is the place where the backend produces its log file : backend.log
and the place as well where logs are centralized, copied for processing.
